import { crearMarap } from './nuevoAgente.js';

export const agenteMarap = crearMarap({ verbose: false });

